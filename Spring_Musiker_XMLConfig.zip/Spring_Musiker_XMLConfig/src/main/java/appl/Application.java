package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.Performer;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			
			
			Performer klavierspieler = ctx.getBean("klavierspieler", Performer.class);
			Performer klavierspieler2 = ctx.getBean("klavierspieler", Performer.class);
			Performer gitarist = (Performer) ctx.getBean("gitarist");
			Performer gitarist2 = (Performer) ctx.getBean("gitarist");
			
			klavierspieler.perform();
			klavierspieler2.perform();
			gitarist.perform();
			gitarist2.perform();
			
			
			
			
			


			
		}
	}
}
