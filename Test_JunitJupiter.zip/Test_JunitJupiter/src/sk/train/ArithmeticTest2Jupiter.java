package sk.train;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

class ArithmeticTest2Jupiter {

	private Arithmetic2 ar;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("setUpBeforeClass()");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("tearDownAfterClass()");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("setUp()");
		ar = new Arithmetic2();
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("tearDown()");
	}

	@Test
	void testSum() {
		Assertions.assertEquals(1.0, ar.sum(0.1, 0.9), 0.0, "Nicht ok");
	}

	@Test
	void testFakultaet() {
		assertEquals(1, ar.fakultaet(1), "Nicht ok");
		assertEquals(120, ar.fakultaet(5), "Nicht ok");
	}

	// @Ignore //wirkt bei Jupiter nicht
	@Disabled
	@Test
	void testFakultaetExact() {
		fail("Not yet implemented");
	}

	// andere Art Exceptions zu testen
	@Test
	void testFakExact() {
		assertEquals(1, ar.fakultaetExact(1), "Nicht ok");
		assertEquals(120, ar.fakultaetExact(5), "Nicht ok");
		assertThrows(ArithmeticException.class, () -> ar.fakultaetExact(13));		

	}

	// parametrisierter Test bei Jupiter

	@ParameterizedTest
	@ValueSource(ints = { 1, 2, 3 })
	void testFakultaetWithValueSource(int argument) {
		assertTrue(argument > 0 && argument < 4);
	}
	
	@ParameterizedTest
	@CsvSource({
	    "1, 1",
	    "2, 2",
	    "3,	6",
	    "4,	24",
	    "5, 120"
	})
	void testFakultaetWithCSVSource(int argument, int expected) {
		System.out.println("arg=" + argument + "\t" + "exp=" + expected);
		assertEquals(expected, ar.fakultaet(argument));
	}
	
	//Nachteil: keine direkte Unterst�tzung von Primitiv-Arrays
	@ParameterizedTest
	@MethodSource("doubleProvider")
	void testSumWithMethodSource(double expected, double arg1, double arg2) {
		System.out.println("arg1=" + arg1 + "\t" + "exp=" + expected);
		assertEquals(expected, ar.sum(arg1, arg2));
	}	
	
	static Stream<Object[]> doubleProvider() {
	    return Stream.of(
	        new Object[]{4.0, 2.0, 2.0}, 
	        new Object[]{0.2, 0.1, 0.1},
	        new Object[]{7.5, 2.0, 5.5});	    
	}

}
