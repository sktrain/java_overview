/* Was bedeutet:
 * <? extends T> bzw. <? super T>
 * 
 */
package sk.train.generics;

import java.util.ArrayList;
import java.util.Date;

public class GenTest {

	public static void main(String[] args) {
	
		  ArrayList<? extends Object> ao = new ArrayList<>();
		  ArrayList<Number> an = new ArrayList<>();
		  ArrayList <? super Integer> ai = new ArrayList<>();
		  
		  ao = an;
		  ai = an; 
	}

}
