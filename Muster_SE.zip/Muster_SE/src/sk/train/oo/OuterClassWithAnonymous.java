package sk.train.oo;
interface Fl�cheBerechnen{
	double fl�che();
}

public class OuterClassWithAnonymous {
	
	private class Inner {
		private int i = 1;
	}
	
	Fl�cheBerechnen print(){
		Inner in = new Inner();
		System.out.println(in.i);
		
		Fl�cheBerechnen anonyminner = new Fl�cheBerechnen()
		{
			public double fl�che(){
				return 0.0;}
		};
		System.out.println(anonyminner.fl�che());
		return anonyminner;
	}
	

	
	public static void main(String[] args){
		OuterClassWithAnonymous oc = new OuterClassWithAnonymous();
		Fl�cheBerechnen f = oc.print();
		System.out.println(f.fl�che());
	}
}
