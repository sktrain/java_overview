package sk.train.ma_verwaltung;

public enum Geschlecht { W, M, D

}
