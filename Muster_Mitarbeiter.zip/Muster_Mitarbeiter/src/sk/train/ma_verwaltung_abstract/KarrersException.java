package sk.train.ma_verwaltung_abstract;

public class KarrersException extends RuntimeException{

	public KarrersException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KarrersException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public KarrersException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public KarrersException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public KarrersException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
