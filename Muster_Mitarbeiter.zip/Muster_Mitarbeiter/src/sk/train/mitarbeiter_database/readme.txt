Basisversion der Mitarbeiterklasse, mit unsauberer Vererbung.
Alternative skizziert mit Arbeiter_HasA.
Erg�nzt um DB-Zugriff und GUI mit JTable.