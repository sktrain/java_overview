package sk.train.mitarbeiter_database;

public class MitarbeiterTest {

	public static void main(String[] args) {

             Mitarbeiter m = new Arbeiter(4711, "Maulwurf",25, 160);
             System.out.println(m.getGehalt());
             
             ((Arbeiter)m).setStdzahl(100);
             
             System.out.println(m.getGehalt());
             
             
             //Das ist das Design-Problem
             m.setGehalt(50000);
             
             System.out.println(m.getGehalt());

	}

}
