package sk.train.mitarbeiter_database;

import java.util.Comparator;

public class OldComparator implements Comparator{

	@Override
	public int compare(Object arg0, Object arg1) {
		Mitarbeiter m0 = (Mitarbeiter)(arg0);
		Mitarbeiter m1 = (Mitarbeiter)(arg1);
		return m0.getName().compareTo(m1.getName());
	}

}
