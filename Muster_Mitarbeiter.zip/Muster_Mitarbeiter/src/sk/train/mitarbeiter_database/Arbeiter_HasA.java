package sk.train.mitarbeiter_database;

/* Has-A ist problemfreier als Is-A */

public class Arbeiter_HasA {
	
	private int stdlohn;
	private int stdzahl;
	private Mitarbeiter ma;
	
	public Arbeiter_HasA(int persnr, String name, int stdlohn, int stdzahl)  {
		super();
		this.stdlohn = stdlohn;
		this.stdzahl = stdzahl;
		ma = new Mitarbeiter(4711, "Maulwurf", stdlohn * stdzahl);
	}

	public int getStdlohn() {
		return stdlohn;
	}

	public void setStdlohn(int stdlohn) {
		ma.setGehalt(stdlohn*stdzahl);
		this.stdlohn = stdlohn;
	}

	public int getStdzahl() {
		return stdzahl;
	}

	public void setStdzahl(int stdzahl) {
		ma.setGehalt(stdlohn*stdzahl);
		this.stdzahl = stdzahl;
	}
	
	//Delegieren (kann durch Eclipse generiert werden)

	/**
	 * @return
	 * @see sk.train.mitarbeiter_database.Mitarbeiter#getName()
	 */
	public String getName() {
		return ma.getName();
	}

	/**
	 * @param name
	 * @see sk.train.mitarbeiter_database.Mitarbeiter#setName(java.lang.String)
	 */
	public void setName(String name) {
		ma.setName(name);
	}

	/**
	 * @return
	 * @see sk.train.mitarbeiter_database.Mitarbeiter#getGehalt()
	 */
	public int getGehalt() {
		return ma.getGehalt();
	}

	/**
	 * @return
	 * @see sk.train.mitarbeiter_database.Mitarbeiter#getPersnr()
	 */
	public int getPersnr() {
		return ma.getPersnr();
	}
	
	
	//Standardmethoden
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Arbeiter_HasA [stdlohn=" + stdlohn + ", stdzahl=" + stdzahl + ", ma=" + ma + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ma == null) ? 0 : ma.hashCode());
		result = prime * result + stdlohn;
		result = prime * result + stdzahl;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Arbeiter_HasA other = (Arbeiter_HasA) obj;
		if (ma == null) {
			if (other.ma != null)
				return false;
		} else if (!ma.equals(other.ma))
			return false;
		if (stdlohn != other.stdlohn)
			return false;
		if (stdzahl != other.stdzahl)
			return false;
		return true;
	}

}
