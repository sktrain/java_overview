package sk.train.mitarbeiter_database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	
	private Connection myconnect;
	
	public Connection createConnection() throws ClassNotFoundException, SQLException{
		Class.forName("org.h2.Driver");
		myconnect = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
		return myconnect;
		
	}
	
	public void closeConnection() throws SQLException{
		myconnect.close();
	}

}
