Maven-Dependencies via Spring-Boot, sonst nichts von Spring-Boot genutzt.
Da jetzt verschiedene Logging-Frameworks im ClassPath und irgendwo der Log-Level
auf DEBUG für Hibernate gesetzt wird:
Entweder jdk-Logging via Property einschalten oder aber (da LogBack benutzt wird)
logback.xml im ClassPath spendieren!