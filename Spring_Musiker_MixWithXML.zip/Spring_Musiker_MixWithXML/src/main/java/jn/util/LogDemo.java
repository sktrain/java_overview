package jn.util;

public class LogDemo {
	public static void main(String[] args) {
		foo(42, "Hello");
	}

	public static void foo(int i, String s) {
		Log.log(i, s);
		bar(3.14);
	}

	public static void bar(double d) {
		Log.log(d);
	}

}
