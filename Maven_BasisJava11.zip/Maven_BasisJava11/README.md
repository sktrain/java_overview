# quickstart
---
Maven-Basis-Projekt für Java11 und Jupiter (JUnit5)