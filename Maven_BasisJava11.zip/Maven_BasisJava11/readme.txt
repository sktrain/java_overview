Maven-Projekt auf Basis Java 11 ohne weitere Dependencies
