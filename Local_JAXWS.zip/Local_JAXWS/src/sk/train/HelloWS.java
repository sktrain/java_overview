package sk.train;

import javax.jws.WebService;

@WebService(endpointInterface = "sk.train.HelloWSIF")
public class HelloWS implements HelloWSIF {
	
	@Override
	public String sayHello(String input) {
		return "Hallo "+input;
	}

}
