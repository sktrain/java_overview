package sk.train;

import javax.jws.WebService;

@WebService
public interface HelloWSIF {

	String sayHello(String input);

}