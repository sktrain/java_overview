package sk.train;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import sk.train.mockito.Database;
import sk.train.mockito.Service;

@ExtendWith(MockitoExtension.class)                         
class ServiceTest {

    @Mock
    Database databaseMock; 
    
    private Service t;
    
    @BeforeEach
    void initialize() {    	
    	 when(databaseMock.isAvailable()).thenReturn(true);  
         t  = new Service(databaseMock);      	
    }

    @Test
    public void testQuery()  {
        assertNotNull(databaseMock);                  
        boolean check = t.query("* from t");                
        assertTrue(check);
    }
}