# Maven_Mockito
---
Maven-Basis-Projekt für Java11, Jupiter (JUnit5) und Mockito